"use client";

import { useState } from "react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // TODO: ligar a supabase.auth.signInWithPassword({ email, password })
  // quando o projeto Supabase estiver criado (ver README).
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    alert("Login ainda não ligado à base de dados — falta configurar o Supabase (ver README).");
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-4">
      <form onSubmit={handleSubmit} className="w-full max-w-sm rounded-xl bg-white border border-[#E7E6F0] p-6">
        <h1 className="text-lg font-medium mb-1">FoodStory Portal</h1>
        <p className="text-sm text-[#6B6B76] mb-6">Inicia sessão para continuar</p>

        <label className="block text-xs text-[#6B6B76] mb-1">Email</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full h-10 rounded-lg border border-[#E7E6F0] px-3 text-sm mb-4"
          placeholder="nome@foodstory.pt"
        />

        <label className="block text-xs text-[#6B6B76] mb-1">Password</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full h-10 rounded-lg border border-[#E7E6F0] px-3 text-sm mb-2"
          placeholder="••••••••"
        />

        <a href="#" className="text-xs text-brand-500 hover:underline">Esqueci-me da password</a>

        <button
          type="submit"
          className="w-full h-10 rounded-lg bg-brand-500 text-white text-sm font-medium mt-4 hover:bg-brand-600 transition-colors"
        >
          Entrar
        </button>
      </form>
    </main>
  );
}
